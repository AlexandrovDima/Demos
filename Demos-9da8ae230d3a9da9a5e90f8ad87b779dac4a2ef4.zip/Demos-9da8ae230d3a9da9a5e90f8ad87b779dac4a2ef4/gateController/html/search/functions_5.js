var searchData=
[
  ['visual_0',['visual',['../classvisual.html#a69c2ba5ce930104f7b70450ba78e4eed',1,'visual']]]
];
