var searchData=
[
  ['via_20udp_20socket_0',['There native gate controller with async mode commander unit via UDP Socket',['../md_readme.html',1,'']]],
  ['visual_1',['visual',['../classvisual.html',1,'visual'],['../classvisual.html#a69c2ba5ce930104f7b70450ba78e4eed',1,'visual::visual()']]],
  ['visual_2ecpp_2',['visual.cpp',['../visual_8cpp.html',1,'']]],
  ['visual_2eh_3',['visual.h',['../visual_8h.html',1,'']]]
];
