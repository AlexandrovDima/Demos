var searchData=
[
  ['visual_0',['visual',['../classvisual.html',1,'']]]
];
