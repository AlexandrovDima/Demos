var searchData=
[
  ['visual_0',['visual',['../a00027.html',1,'']]]
];
