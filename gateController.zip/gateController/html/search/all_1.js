var searchData=
[
  ['bindresult_0',['bindresult',['../a00023.html#a92028f7238a9a0d2299a1905c461305e',1,'Udp_sock']]]
];
