var searchData=
[
  ['sending_0',['sending',['../a00023.html#a76ba57a34e356d673815dd2f60bda497',1,'Udp_sock::sending(QByteArray, QString, quint16)'],['../a00023.html#a1d2eb9c7f039b595e04746ccd8aa1d25',1,'Udp_sock::sending(QByteArray)']]],
  ['socket_1',['There native gate controller with async mode commander unit via UDP Socket',['../a00036.html',1,'']]]
];
