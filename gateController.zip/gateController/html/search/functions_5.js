var searchData=
[
  ['visual_0',['visual',['../a00027.html#a69c2ba5ce930104f7b70450ba78e4eed',1,'visual']]]
];
