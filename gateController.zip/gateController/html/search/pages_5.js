var searchData=
[
  ['socket_0',['There native gate controller with async mode commander unit via UDP Socket',['../a00036.html',1,'']]]
];
